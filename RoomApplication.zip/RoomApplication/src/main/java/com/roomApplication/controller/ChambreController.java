package com.roomApplication.controller;

import com.roomApplication.dao.ChambreDao;
import com.roomApplication.model.Chambre;
import com.roomApplication.repository.ChambreRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.validation.Valid;
import java.util.Optional;

@Controller
public class ChambreController {

    private
    ChambreRepository chambreRepository;
    private ChambreDao chambreDao;

    @Autowired
    public ChambreController(ChambreRepository chambreRepository, ChambreDao chambreDao) {
        this.chambreRepository = chambreRepository;
        this.chambreDao = chambreDao;
    }

    @RequestMapping(value ="chambre",method = RequestMethod.GET)
    public String index(ModelMap model) {
        Chambre chambre = new Chambre();
        model.addAttribute("chambre",chambre);
        return "chambres";
    }


    @RequestMapping(value = "chambre",method = RequestMethod.POST)
    public String saveRoom(@Valid Chambre chambre, BindingResult result, ModelMap model, RedirectAttributes redirectAttributes){
        if(result.hasErrors()){
            System.out.println("Echec de l'enregistrement !");
            return "chambres";
        }
        chambreRepository.save(chambre);
        return "redirect:/chambrelist";
    }


    @GetMapping("chambrelist")
    public String ShowPage(Model model, @RequestParam(defaultValue = "0") int page){
        model.addAttribute("data", chambreRepository.findAll(new PageRequest(page,8) {
        }));
        model.addAttribute("currentPage",page);
        return "chambreslist";
    }
}
