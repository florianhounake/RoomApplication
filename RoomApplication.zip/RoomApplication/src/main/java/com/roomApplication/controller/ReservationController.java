package com.roomApplication.controller;

import com.roomApplication.model.Reservation;
import com.roomApplication.repository.ReservationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.validation.Valid;

@Controller
public class ReservationController {

    private ReservationRepository reservationRepository;

    @Autowired
    public ReservationController(ReservationRepository reservationRepository) {
        this.reservationRepository = reservationRepository;
    }

    @RequestMapping(value ="reservation",method = RequestMethod.GET)
    public String index(ModelMap model) {
        Reservation reservation = new Reservation();
        model.addAttribute("reservation",reservation);
        return "reservation";
    }

    @RequestMapping(value = "reservation",method = RequestMethod.POST)
    public String saveReservation(@Valid Reservation reservation, BindingResult result, ModelMap model, RedirectAttributes redirectAttributes){
        if(result.hasErrors()){
            System.out.println("Echec de la reservation !");
            return "reservation";
        }
        reservationRepository.save(reservation);
        return "redirect:/reservationlist";
    }

    @GetMapping("reservationlist")
    public String ShowPage(Model model, @RequestParam(defaultValue = "0") int page){
        model.addAttribute("data", reservationRepository.findAll(new PageRequest(page,6) {
        }));
        model.addAttribute("currentPage",page);
        return "reservationlist";
    }
}
