package com.roomApplication.model;

import javax.persistence.*;
import javax.validation.constraints.NotEmpty;

@Entity
@Table(name="Reservation")
public class Reservation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id", nullable=false)
    private long id;

    @NotEmpty
    @Column(name="identite")
    private String identite;

    @NotEmpty
    @Column(name="typeIdentifiant")
    private String typeIdentifiant;

    @NotEmpty
    @Column(name="numeroIdentifiant")
    private String numeroIdentifiant;

    @NotEmpty
    @Column(name="type")
    private String type;

    @NotEmpty
    @Column(name="montant")
    private String montant;

    @NotEmpty
    @Column(name="chambre")
    private String chambre;

    public String getChambre() {
        return chambre;
    }

    public void setChambre(String chambre) {
        this.chambre = chambre;
    }

    public Reservation(long id, String identite, String typeIdentifiant, String numeroIdentifiant, String type, String montant, String chambre) {
        this.id = id;
        this.identite = identite;
        this.typeIdentifiant = typeIdentifiant;
        this.numeroIdentifiant = numeroIdentifiant;
        this.type = type;
        this.montant = montant;
        this.chambre=chambre;
    }

    public Reservation() {
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getIdentite() {
        return identite;
    }

    public void setIdentite(String identite) {
        this.identite = identite;
    }

    public String getTypeIdentifiant() {
        return typeIdentifiant;
    }

    public void setTypeIdentifiant(String typeIdentifiant) {
        this.typeIdentifiant = typeIdentifiant;
    }

    public String getNumeroIdentifiant() {
        return numeroIdentifiant;
    }

    public void setNumeroIdentifiant(String numeroIdentifiant) {
        this.numeroIdentifiant = numeroIdentifiant;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getMontant() {
        return montant;
    }

    public void setMontant(String montant) {
        this.montant = montant;
    }

    @Override
    public String toString() {
        return "Reservation{" +
                "id=" + id +
                ", identite='" + identite + '\'' +
                ", typeIdentifiant='" + typeIdentifiant + '\'' +
                ", numeroIdentifiant='" + numeroIdentifiant + '\'' +
                ", type='" + type + '\'' +
                ", montant='" + montant + '\'' +
                ", chambre='" + chambre + '\'' +
                '}';
    }
}
