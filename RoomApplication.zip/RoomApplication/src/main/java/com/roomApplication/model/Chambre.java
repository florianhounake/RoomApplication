package com.roomApplication.model;

import javax.persistence.*;
import javax.validation.constraints.NotEmpty;

@Entity
@Table(name="chambre")
public class Chambre {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id", nullable=false)
    private long id;

    @NotEmpty
    @Column(name="numero")
    private String numero;

    @NotEmpty
    @Column(name="prix")
    private String prix;

    @NotEmpty
    @Column(name="type")
    private String type;

    @NotEmpty
    @Column(name="etat")
    private String etat;

    @Override
    public String toString() {
        return "Chambre{" +
                "id=" + id +
                ", numero='" + numero + '\'' +
                ", prix='" + prix + '\'' +
                ", type='" + type + '\'' +
                ", etat='" + etat + '\'' +
                '}';
    }

    public Chambre() {
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Chambre(long id, String numero, String prix, String etat, String type) {
        this.id = id;
        this.numero = numero;
        this.prix = prix;
        this.etat = etat;
        this.type = type;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getPrix() {
        return prix;
    }

    public void setPrix(String prix) {
        this.prix = prix;
    }

    public String getEtat() {
        return etat;
    }

    public void setEtat(String etat) {
        this.etat = etat;
    }


}
