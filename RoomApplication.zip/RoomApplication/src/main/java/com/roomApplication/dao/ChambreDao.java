package com.roomApplication.dao;

import com.roomApplication.model.Chambre;
import com.roomApplication.repository.ChambreRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class ChambreDao {

    @Autowired
    private ChambreRepository chambreRepository;

    public Optional<Chambre> findOne(long id){
        return chambreRepository.findById(id);
    }
}
