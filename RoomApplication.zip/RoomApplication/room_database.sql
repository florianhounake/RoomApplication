-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  ven. 04 jan. 2019 à 15:15
-- Version du serveur :  10.1.30-MariaDB
-- Version de PHP :  7.2.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `room_database`
--

-- --------------------------------------------------------

--
-- Structure de la table `chambre`
--

CREATE TABLE `chambre` (
  `id` bigint(20) NOT NULL,
  `create_date` datetime DEFAULT NULL,
  `etat` varchar(255) DEFAULT NULL,
  `numero` varchar(255) DEFAULT NULL,
  `prix` int(11) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `chambre`
--

INSERT INTO `chambre` (`id`, `create_date`, `etat`, `numero`, `prix`, `type`) VALUES
(1, NULL, 'Libre', '42A', 400, 'Simple'),
(2, NULL, 'Libre', '42B', 4000, 'VIP'),
(3, NULL, 'Reservé', '42C', 40000, 'VIP'),
(4, NULL, 'Maintenance', '42D', 400000, 'VIP'),
(5, NULL, 'Occupée', '42E', 300, 'VIP'),
(6, NULL, 'Reservé', '42F', 3000, 'VIP'),
(7, NULL, 'Reservé', '42G', 120000, 'VIP'),
(8, NULL, 'Libre', 'LRB10', 25000, 'Simple'),
(9, NULL, 'Reservé', '42H', 520000, 'VIP'),
(10, NULL, 'Libre', '48D-MC Laren', 400000, 'VIP'),
(11, NULL, 'Libre', '42T', 2500, 'Simple');

-- --------------------------------------------------------

--
-- Structure de la table `reservation`
--

CREATE TABLE `reservation` (
  `id` bigint(20) NOT NULL,
  `identite` varchar(255) DEFAULT NULL,
  `montant` varchar(255) DEFAULT NULL,
  `numero_identifiant` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `type_identifiant` varchar(255) DEFAULT NULL,
  `chambre` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `reservation`
--

INSERT INTO `reservation` (`id`, `identite`, `montant`, `numero_identifiant`, `type`, `type_identifiant`, `chambre`) VALUES
(1, 'Florian Jacques Dodji HOUNAKE KOUASSI', '400000', '12341231234', 'VIP', 'Carte d\'identité', '48D-MC Laren'),
(2, 'Martial AHADJI', '520000', '98749879874', 'VIP', 'Carte d\'identité', '42H'),
(3, 'Marguerite KOMLAN', '4000', '98749879873', 'VIP', 'Carte d\'identité', '42B');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `chambre`
--
ALTER TABLE `chambre`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `reservation`
--
ALTER TABLE `reservation`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `chambre`
--
ALTER TABLE `chambre`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT pour la table `reservation`
--
ALTER TABLE `reservation`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
